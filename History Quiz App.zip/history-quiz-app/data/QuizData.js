export default data = [
    {
        question: "     1000원짜리 지폐의 주인공으로,\n성리학을 체계화한 인물은 누구인가요?",
        options: ["이이","정약용","이황","정도전"],
        correct_option: "이황", description: "퇴계 이황은 평생을 학문 연구에 힘쓰며 \n            성리학을 체계화하였다."
    },
    {
        question: "조선의 통치 이념(사상)은 무엇인가요?",
        options: ["불교","도교","개신교", "성리학"],
        correct_option: "성리학", description: "조선은 성리학을 통치 이념으로 삼고\n    나라를 다스리는 데 사용되었다."
    },
    // {
    //     question: "What land animal can open its mouth the widest?",
    //     options: ["Alligator","Crocodile","Baboon","Hippo"],
    //     correct_option: "Hippo"
    // },
    // {
    //     question: "What is the largest animal on Earth?",
    //     options: ["The African elephant","The blue whale","The sperm whale","The giant squid"],
    //     correct_option: "The blue whale"
    // },
    // {
    //     question: "What is the only flying mammal?",
    //     options: ["The bat","The flying squirrel","The bald eagle","The colugo"],
    //     correct_option: "The bat"
    // }
]