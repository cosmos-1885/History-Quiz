import { COLORS, SIZES } from './theme';

export {
    COLORS,
    SIZES
}